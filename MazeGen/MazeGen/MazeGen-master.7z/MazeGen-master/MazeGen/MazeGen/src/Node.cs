﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeGen
{
    class Node
    {
        public Node(int _xPos, int _yPos)
        {
            xPos = _xPos;
            yPos = _yPos;
        }

        public int xPos;
        public int yPos;

        public bool beenVisited = false;

        bool m_northWall = true;
        bool m_eastWall = true;
        bool m_southWall = true;
        bool m_westWall = true;

        //string m_direction = "";

        public static List<Node> GetSurroundingNodes(Node currentNode)
        {
            List<Node> surroundingNodes = new List<Node>();

            //TR CORNER
            if (currentNode.xPos == Maze.m_mazeWidth && currentNode.yPos == 0)
            {
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, bottomNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(bottomNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }

            //BR CORNER
            if (currentNode.xPos == Maze.m_mazeWidth && currentNode.yPos == Maze.m_mazeHeight)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(topNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }

            //BL CORNER
            if (currentNode.xPos == 0 && currentNode.yPos == Maze.m_mazeHeight)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node rightNode = Program.finalMaze[currentNode.xPos + 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, rightNode);

                surroundingNodes.Add(topNode);
                surroundingNodes.Add(rightNode);
                return surroundingNodes;
            }

            //TL CORNER
            if (currentNode.xPos == 0 && currentNode.yPos == 0)
            {
                Node rightNode = Program.finalMaze[currentNode.xPos + 1, currentNode.yPos];
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];

                GetDirectionFromCurrentNode(currentNode, rightNode);
                GetDirectionFromCurrentNode(currentNode, bottomNode);

                surroundingNodes.Add(rightNode);
                surroundingNodes.Add(bottomNode);
                return surroundingNodes;
            }

            //TOP EDGE
            if (currentNode.xPos >= 1 &&  currentNode.yPos == 0 && currentNode.xPos <= Maze.m_mazeWidth - 1)
            {
                Node rightNode = Program.finalMaze[currentNode.xPos, currentNode.yPos];
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, rightNode);
                GetDirectionFromCurrentNode(currentNode, bottomNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(rightNode);
                surroundingNodes.Add(bottomNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }

            //RIGHT EDGE
            if (currentNode.xPos == Maze.m_mazeWidth  && currentNode.yPos >= 1 && currentNode.yPos <= Maze.m_mazeHeight - 1)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, bottomNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(topNode);
                surroundingNodes.Add(bottomNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }

            //BOTTOM EDGE
            if (currentNode.yPos == Maze.m_mazeHeight && currentNode.xPos >= 1 && currentNode.xPos <= Maze.m_mazeWidth - 1)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node rightNode = Program.finalMaze[currentNode.xPos + 1, currentNode.yPos];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, rightNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(rightNode);
                surroundingNodes.Add(topNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }

            //LEFT EDGE
            if (currentNode.xPos == 0 && currentNode.yPos >= 1 && currentNode.yPos < Maze.m_mazeHeight - 1)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node rightNode = Program.finalMaze[currentNode.xPos + 1, currentNode.yPos];
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, rightNode);
                GetDirectionFromCurrentNode(currentNode, bottomNode);

                surroundingNodes.Add(topNode);
                surroundingNodes.Add(rightNode);
                surroundingNodes.Add(bottomNode);
                return surroundingNodes;
            }

            //CHECK REMAINING NODES
            if (currentNode.xPos >= 1 && currentNode.xPos < Maze.m_mazeWidth - 1 | currentNode.yPos >= 1 && currentNode.yPos < Maze.m_mazeHeight)
            {
                Node topNode = Program.finalMaze[currentNode.xPos, currentNode.yPos - 1];
                Node rightNode = Program.finalMaze[currentNode.xPos + 1, currentNode.yPos];
                Node bottomNode = Program.finalMaze[currentNode.xPos, currentNode.yPos + 1];
                Node leftNode = Program.finalMaze[currentNode.xPos - 1, currentNode.yPos];

                GetDirectionFromCurrentNode(currentNode, topNode);
                GetDirectionFromCurrentNode(currentNode, rightNode);
                GetDirectionFromCurrentNode(currentNode, bottomNode);
                GetDirectionFromCurrentNode(currentNode, leftNode);

                surroundingNodes.Add(topNode);
                surroundingNodes.Add(rightNode);
                surroundingNodes.Add(bottomNode);
                surroundingNodes.Add(leftNode);
                return surroundingNodes;
            }
            return surroundingNodes;
        }

        public static void GetDirectionFromCurrentNode(Node currentNode, Node selectedNode)
        {
            if (selectedNode.yPos < currentNode.yPos)
            {
                //currentNode.m_direction = "NORTH";
                currentNode.m_northWall = false;
                selectedNode.m_southWall = false;
            }

            if (selectedNode.xPos > currentNode.xPos)
            {
                //currentNode.m_direction = "EAST";
                currentNode.m_eastWall = false;
                selectedNode.m_westWall = false;
            }

            if (selectedNode.yPos > currentNode.yPos)
            {
                //currentNode.m_direction = "SOUTH";
                currentNode.m_southWall = false;
                selectedNode.m_northWall = false;
            }

            if (selectedNode.xPos < currentNode.xPos)
            {
                //currentNode.m_direction = "WEST";
                currentNode.m_westWall = false;
                selectedNode.m_eastWall = false;
            }
        }
    }
}
