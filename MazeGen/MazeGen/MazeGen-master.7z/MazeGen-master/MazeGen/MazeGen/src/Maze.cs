﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeGen
{
    class Maze
    {
        public static int m_mazeWidth = 10;
        public static int m_mazeHeight = 10;

        public static Node[,] GenerateMaze(int _width, int _height)
        {
            Node[,] m_tempMaze = new Node[_width, _height];

            for (int j = 0; j < _width; j++)
            {
                for (int i = 0; i < _height; i++)
                {
                    m_tempMaze[i,j] = new Node(i,j);
                }
            }
            return m_tempMaze;
        }

        public static void GenerateRecursiveBacktrackMaze(int _xStartPos, int _yStartPos)
        {
            bool allNodesVisited = false;
            List<Node> visitedNodes = new List<Node>();

            Node currentNode = Program.finalMaze[_xStartPos, _yStartPos];
            currentNode.beenVisited = true;
            visitedNodes.Add(currentNode);

            while (allNodesVisited == false)
            {
                List<Node> surroundingNodes = Node.GetSurroundingNodes(currentNode);
                List<Node> unvisitedSurroundingNodes = new List<Node>();

                //CHECKS FOR SURROUNDING NODES THAT HAVE NOT BEEN VISITED
                foreach (Node neighbour in surroundingNodes)
                {
                    if (neighbour.beenVisited == false)
                    unvisitedSurroundingNodes.Add(neighbour);
                }

                //START BACKTRACKING
                if (unvisitedSurroundingNodes.Count == 0)
                {
                    int lastIndex = visitedNodes.Count - 1;
                    currentNode = visitedNodes[lastIndex];

                   surroundingNodes = Node.GetSurroundingNodes(currentNode);
                   foreach (Node neighbour in surroundingNodes)
                   {
                       if (neighbour.beenVisited == false)
                           unvisitedSurroundingNodes.Add(neighbour);
                   }
                }

                if (unvisitedSurroundingNodes.Count != 0)
                {
                    Random random = new Random();
                    int randomNumber = random.Next(0, unvisitedSurroundingNodes.Count);//ARRAY INDEX
                    currentNode = unvisitedSurroundingNodes[randomNumber];
                    currentNode.beenVisited = true;
                    visitedNodes.Add(currentNode);
                }
            }
            //DRAW MAZE
            foreach (Node node in visitedNodes)
            {
                
            }
            allNodesVisited = true;
        }
    }
}
